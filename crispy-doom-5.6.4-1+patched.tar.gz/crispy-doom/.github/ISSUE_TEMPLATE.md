<!--
  Thank you for reporting a bug in Crispy Doom. Please complete the following template
  so that we can better diagnose the source of your problem.
-->

### Background

Version of Crispy Doom:

Operating System and version:

Game: (Doom/Heretic/Hexen/Strife/other)

Any loaded WADs and mods (please include full command line):

### Bug description

Observed behavior:

Expected behavior:

