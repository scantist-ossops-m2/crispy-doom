<!--
  Thank you for reporting a bug in Chocolate Doom. Please complete
  the following template so that we can better diagnose the source
  of your problem.

  To save yourself some time, you may want to check the FAQ and the
  NOT-BUGS list for solutions to some common problems:

     https://www.chocolate-doom.org/wiki/index.php/FAQ
     https://www.chocolate-doom.org/not-bugs
-->

### Background

Version of Chocolate Doom:

Operating System and version:

Game: (Doom/Heretic/Hexen/Strife/other)

Any loaded WADs and mods (please include full command line):

### Bug description

Observed behavior:

Expected behavior:

